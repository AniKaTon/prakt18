<?php 	
include_once "../engine/connect.php";
include_once "../engine/function.php";

if (isset($_POST['submit'])) 
{
	include_once "../engine/array.php";
	
	$list = $_POST['list'];

	if (isset($_POST['kurs'])) {
	foreach ($_POST['kurs'] as $key => $value)
			{
				$radio = $value;
			}
		} else $radio  = '';
		echo '<br>Вы зарегистрированы с данными:' . '<br>Имя: ' . $mas[1] . '<br>Фамилия: ' . $mas[2] 
			. '<br>Отчество: ' .  $mas[3] . '<br>Почта: ' . $mas[4] . '<br>Пароль: ' . $mas[5]
			. '<br>Логин: ' . $mas[6] . '<br>Учебное заведение: ' . $list . '<br>Курс: ' . $radio; 

	$connect->query("INSERT INTO `user` (`name`, `surname`, `patronymic`, `email`, `password`, `login`, `college`,
	 `kurs`, `avatar`) VALUES ('$mas[1]', '$mas[2]', '$mas[3]', '$mas[4]', '$mas[5]', '$mas[6]', '$list', '$radio', '../photo.jpg'); ");	
}

$connect->close();