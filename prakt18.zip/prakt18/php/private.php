<?php
include_once "../engine/connect.php";
include_once "../engine/function.php";

$login = $_POST['login'];
$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$login';");
$row = $query->fetch_assoc();

$check = $row['kurs'];
$college = $row['college'];

if(isset($_FILES['avatar']))
{

	$oldName = $_FILES['avatar']['name'];
	$types = array('.jpg' , '.png' , '.jpeg' , '.bmp');
	$name = substr($oldName, strpos($oldName, '.'), strlen($oldName)-1);
	
	if ($_FILES['avatar']['size'] > 0 and in_array($name, $types)) 
	{
		$path = "../images/";
		$filename = rand(1000,10000) . $name;
		$fullname = $path . $filename;
		$tmp_name = $_FILES['avatar']['tmp_name'];
		move_uploaded_file($tmp_name , $fullname);
		$connect->query("UPDATE `user` SET `avatar` = '$fullname' WHERE `login` = '$login'");
	}
}

if (isset($_POST['kurs']))
{
	foreach ($_POST['kurs'] as $value)
		$radio = $value;
} else $radio = "";



if (isset($_POST['subm'])) {

	$connect->query("UPDATE user SET name 	= '" . $_POST['name'] 	 	. "',
							surname 		= '" . $_POST['surname'] 	. "',
							email 			= '" . $_POST['email'] 	 	. "',
							password 		= '" . $_POST['password']	. "',
							college 		= '" . $_POST['list'] 	 	. "',
							kurs 			= '" . $radio 	 	. "'	
							WHERE login = '" . $_POST['login'] . "' ");
	echo "Изменения приняты";
} 



$connect->close();	