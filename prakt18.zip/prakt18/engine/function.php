<?php
function check($value, $name, $pattern)
{
	if (!empty($_POST["$value"]))
	{	
		
		$field = $_POST["$value"];
		if (!preg_match($pattern, $field)) {
			die('Неккоректный ввод: ' . $name);
		}

	} else die('Пустое поле: ' . $name);
	
	return $field;
}

function test($radio)
{
	foreach ($_POST['radio'] as $key => $value) {
		if ($value == $radio) {
			return true;
		}
	}
	return false;
}
